import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Controller {
    Random random = new Random();
    @FXML
    private Label resultLabel;

    @FXML
    private ImageView actionImageView;

    @FXML
    private Button downButton;

    @FXML
    private Button leftButton;

    @FXML
    private Button rightButton;

    @FXML
    private Button upButton;

    // NON FXML
    private Boolean playing = true;
    private List<String> directions = new ArrayList<>(Arrays.asList("up","down","left","right"));
    private int randIndex = random.nextInt(directions.size());
    private String startingDirection = directions.get(randIndex);
    public void checkPlayingDirection(String chosenDirection, Button button, String fileName){
        if(chosenDirection.equals(startingDirection)){
            // SET THE IMAGE AND DISABLE BUTTON
            button.setDisable(true);
            actionImageView.setImage(new Image("file:images/" + fileName + ".png"));
            directions.remove(directions.indexOf(chosenDirection));
            // GET NEW DIRECTION
            randIndex = random.nextInt(directions.size());
            startingDirection = directions.get(randIndex);
            // IF DONE
            if(directions.size() == 1){
                if(playing){
                    resultLabel.setText("You Win!");
                    upButton.setDisable(true);
                    downButton.setDisable(true);
                    leftButton.setDisable(true);
                    rightButton.setDisable(true);
                } else {
                    resultLabel.setText("You Lose...");
                    upButton.setDisable(true);
                    downButton.setDisable(true);
                    leftButton.setDisable(true);
                    rightButton.setDisable(true);
                }
            }
        } else {
            directions =  new ArrayList<>(Arrays.asList("up","down","left","right"));
            randIndex = random.nextInt(directions.size());
            startingDirection = directions.get(randIndex);
            if(!playing){
                actionImageView.setImage(new Image("file:images/regularFace.png"));
                playing = true;
            } else {
                actionImageView.setImage(new Image("file:images/neutralHands.png"));
                playing = false;
            }
            upButton.setDisable(false);
            downButton.setDisable(false);
            leftButton.setDisable(false);
            rightButton.setDisable(false);
        }
    }

    @FXML
    void goDown(ActionEvent event) {
        if(playing){
            checkPlayingDirection("down", downButton, "faceDown");
        } else {
            checkPlayingDirection("down", downButton, "handDown");
        }
    }

    @FXML
    void goLeft(ActionEvent event) {
        if(playing){
            checkPlayingDirection("left", leftButton, "faceLeft");
        } else {
            checkPlayingDirection("left", leftButton, "handLeft");
        }
    }

    @FXML
    void goRight(ActionEvent event) {
        if(playing){
            checkPlayingDirection("right", rightButton, "faceRight");
        } else {
            checkPlayingDirection("right", rightButton, "handRight");
        }
    }

    @FXML
    void goUp(ActionEvent event) {
        if(playing){
            checkPlayingDirection("up", upButton, "faceUp");
        } else {
            checkPlayingDirection("up", upButton, "handUp");
        }
    }

}
